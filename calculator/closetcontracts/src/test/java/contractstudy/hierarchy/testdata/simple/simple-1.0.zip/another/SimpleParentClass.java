package contractstudy.hierarchy.testdata.simple.another;

/**
 * @author Kamil Jezek [kamil.jezek@verifalabs.com]
 */
public class SimpleParentClass extends SimpleParentParentInProject {

    private void privateM() {}

    public void publicM() {}
}
