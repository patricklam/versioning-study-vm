package contractstudy.hierarchy.testdata.simple.multiple;

/**
 * @author Kamil Jezek [kamil.jezek@verifalabs.com]
 */
public interface MultipleA {

    void method1();
    void method2();
}
