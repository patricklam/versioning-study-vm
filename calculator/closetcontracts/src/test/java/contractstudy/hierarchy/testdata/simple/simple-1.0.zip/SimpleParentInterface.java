package contractstudy.hierarchy.testdata.simple;

import contractstudy.hierarchy.testdata.depsa.SimpleParentParentInterfaceA;

/**
 * @author Kamil Jezek [kamil.jezek@verifalabs.com]
 */
public interface SimpleParentInterface extends SimpleParentParentInterfaceA {

    void method();
}
