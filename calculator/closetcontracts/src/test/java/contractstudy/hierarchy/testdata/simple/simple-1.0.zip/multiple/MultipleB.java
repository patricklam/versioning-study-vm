package contractstudy.hierarchy.testdata.simple.multiple;

/**
 * @author Kamil Jezek [kamil.jezek@verifalabs.com]
 */
public interface MultipleB {
}
