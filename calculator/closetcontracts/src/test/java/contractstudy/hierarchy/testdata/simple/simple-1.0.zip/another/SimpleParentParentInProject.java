package contractstudy.hierarchy.testdata.simple.another;

import contractstudy.hierarchy.testdata.depsa.SimpleParentParentClassA;

/**
 * @author Kamil Jezek [kamil.jezek@verifalabs.com]
 */
public class SimpleParentParentInProject extends SimpleParentParentClassA {

    public void parentParentInProjectMethod() {}
}
